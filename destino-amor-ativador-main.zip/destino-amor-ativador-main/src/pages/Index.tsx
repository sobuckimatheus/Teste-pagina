import { Hero } from "@/components/Hero";
import { Testimonials } from "@/components/Testimonials";
import { PrayerAlignment } from "@/components/PrayerAlignment";
import { EmotionalConnection } from "@/components/EmotionalConnection";
import { ValueProposition } from "@/components/ValueProposition";
import { WhatYouReceive } from "@/components/WhatYouReceive";
import { BonusItems } from "@/components/BonusItems";
import { PricingOffer } from "@/components/PricingOffer";
import { Guarantee } from "@/components/Guarantee";
import { About } from "@/components/About";
import { FAQ } from "@/components/FAQ";

const Index = () => {
  return (
    <main className="min-h-screen">
      <Hero />
      <Testimonials />
      <EmotionalConnection />
      <ValueProposition />
      <PrayerAlignment />
      <WhatYouReceive />
      <BonusItems />
      <PricingOffer />
      <Guarantee />
      <About />
      <FAQ />
    </main>
  );
};

export default Index;
