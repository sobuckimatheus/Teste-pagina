import { Button } from "@/components/ui/button";
import { Check, Shield, Clock } from "lucide-react";

export const PricingOffer = () => {
  return (
    <section className="py-10 px-4 md:px-8 bg-background">
      <div className="max-w-3xl mx-auto">
        <div className="bg-gradient-to-b from-gray-900 to-gray-800 rounded-3xl p-8 md:p-12 shadow-2xl border border-gray-700">
          {/* Título Principal */}
          <h2 className="text-xl md:text-2xl text-white text-center mb-3 leading-tight">
            Tenha <span className="text-yellow-400 font-semibold">acesso imediato</span> a Oração Profética do Seu
            Futuro Marido
          </h2>

          {/* Super Bônus */}
          <p className="text-yellow-400 text-center font-semibold text-lg md:text-xl mb-4">+ 2 super bônus</p>

          {/* Lista de Bônus */}
          <div className="space-y-2 mb-4">
            <div className="flex items-start gap-3">
              <Check className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
              <p className="text-white text-base md:text-lg">Limpezas terapêuticas + reprogramação de crenças</p>
            </div>
            <div className="flex items-start gap-3">
              <Check className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
              <p className="text-white text-base md:text-lg">Oração de Quebra de Maldições e Traumas Genéticos</p>
            </div>
          </div>

          {/* Bônus Exclusivos */}
          <p className="text-yellow-400 text-center font-semibold text-lg md:text-xl mb-4">+ Bônus Exclusivos</p>

          {/* Lista de Bônus Exclusivos */}
          <div className="space-y-2 mb-6">
            <div className="flex items-start gap-3">
              <Check className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
              <p className="text-white text-base md:text-lg">Livro: Devocional 365 dias. Priorize Deus</p>
            </div>
            <div className="flex items-start gap-3">
              <Check className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
              <p className="text-white text-base md:text-lg">Resumo Bíblico - De Gênesis ao Apocalipse</p>
            </div>
            <div className="flex items-start gap-3">
              <Check className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
              <p className="text-white text-base md:text-lg">
                Enciclopédia da vida dos personagens bíblicos (De A a Z)
              </p>
            </div>
          </div>

          {/* Preço */}
          <div className="text-center mb-6">
            <p className="text-gray-400 line-through text-lg mb-1">De R$ 197 por apenas</p>
            <p className="text-green-400 text-6xl md:text-7xl font-bold mb-1">R$ 29,90</p>
            <p className="text-white text-xl mb-1">à vista</p>
            <p className="text-gray-300 text-lg">Ou 6x R$5,66</p>
          </div>

          {/* CTA Button */}
          <Button
            size="lg"
            asChild
            className="w-full bg-green-600 hover:bg-green-700 text-white font-bold text-lg md:text-xl py-6 md:py-7 rounded-xl shadow-lg hover:shadow-xl transition-all"
          >
            <a href="https://pay.kirvano.com/e95d405f-17e7-4ad2-9367-3bc320138647" target="_blank" rel="noopener noreferrer">
              QUERO DESCOBRIR AGORA
            </a>
          </Button>

          {/* Benefícios */}
          <div className="mt-8 space-y-4">
            <p className="text-white text-center text-xl font-semibold">
              Resultado em menos de 5 minutos
            </p>
            
            <div className="flex flex-col items-center gap-3">
              <div className="flex items-center gap-2">
                <Check className="w-6 h-6 text-green-400" />
                <span className="text-green-400 font-semibold text-lg">Acesso Imediato</span>
              </div>
              
              <div className="flex items-center gap-2">
                <Shield className="w-6 h-6 text-blue-400" />
                <span className="text-blue-400 font-semibold text-lg">Garantia Total</span>
              </div>
              
              <div className="flex items-center gap-2">
                <Clock className="w-6 h-6 text-green-400" />
                <span className="text-green-400 font-semibold text-lg">Suporte 24h</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
