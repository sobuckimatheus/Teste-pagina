export const EmotionalConnection = () => {
  return (
    <section className="px-4 md:px-8 bg-gradient-to-b from-background to-cream">
      <div className="max-w-4xl mx-auto text-center animate-fade-in-up">
        <h2 className="text-xl md:text-4xl font-serif font-bold text-primary mb-4 leading-tight">
          Você já sentiu que está tão perto, mas algo sempre te impede de viver o relacionamento que você sonha?
        </h2>
        
        <p className="text-base md:text-lg text-foreground/80 mb-2 leading-relaxed">
          Como se sua alma soubesse que existe alguém…
        </p>
        
        <p className="text-base md:text-lg text-foreground/80 mb-6 leading-relaxed font-medium">
          …mas o caminho até esse encontro parece travado?
        </p>

        <div className="space-y-2 text-center max-w-2xl mx-auto">
          <p className="text-lg md:text-xl text-primary font-semibold">
            Você não está exagerando.
          </p>
          <p className="text-lg md:text-xl text-primary font-semibold">
            E você não está imaginando coisas.
          </p>
        </div>
      </div>
    </section>
  );
};
