import devotionalBook from "@/assets/devotional-365.png";
import biblicalSummary from "@/assets/biblical-summary.png";
import biblicalEncyclopedia from "@/assets/biblical-encyclopedia.png";

export const BonusItems = () => {
  return (
    <section className="pb-10 px-4 md:px-8 bg-black">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-5xl font-bold text-center mb-8">
          <span className="text-yellow-400">Você também vai receber</span>
        </h2>

        <div className="space-y-6">
          {/* Card 1 - Devocional */}
          <div className="bg-gradient-to-b from-gray-900 to-gray-800 rounded-3xl p-6 md:p-8 border border-gray-700">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="w-48 h-48 flex-shrink-0">
                <img 
                  src={devotionalBook} 
                  alt="Livro Devocional 365 dias"
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold text-yellow-400 mb-2">
                  Livro: Devocional 365 dias. Priorize Deus
                </h3>
                <p className="text-lg md:text-xl text-white/90 mb-3">
                  Livro digital para manter você conectado com Deus e seguindo seus princípios
                </p>
                <p className="text-lg">
                  <span className="text-red-500 line-through">De: R$87</span>{" "}
                  <span className="text-white">por</span>{" "}
                  <span className="text-yellow-400 font-bold text-2xl">GRATUITO</span>
                </p>
              </div>
            </div>
          </div>

          {/* Card 2 - Resumo Bíblico */}
          <div className="bg-gradient-to-b from-gray-900 to-gray-800 rounded-3xl p-6 md:p-8 border border-gray-700">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="w-48 h-48 flex-shrink-0">
                <img 
                  src={biblicalSummary} 
                  alt="Resumo Bíblico"
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold text-yellow-400 mb-2">
                  Resumo Bíblico - De Gênesis ao Apocalipse
                </h3>
                <p className="text-lg md:text-xl text-white/90 mb-3">
                  Entenda toda a narrativa da Bíblia de forma simples, rápida e profunda. Neste resumo direto ao ponto, você vai percorrer os principais acontecimentos, personagens e ensinamentos de cada livro
                </p>
                <p className="text-lg">
                  <span className="text-red-500 line-through">De: R$29,90</span>{" "}
                  <span className="text-white">por</span>{" "}
                  <span className="text-yellow-400 font-bold text-2xl">GRATUITO</span>
                </p>
              </div>
            </div>
          </div>

          {/* Card 3 - Enciclopédia */}
          <div className="bg-gradient-to-b from-gray-900 to-gray-800 rounded-3xl p-6 md:p-8 border border-gray-700">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="w-48 h-48 flex-shrink-0">
                <img 
                  src={biblicalEncyclopedia} 
                  alt="Enciclopédia dos Personagens Bíblicos"
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold text-yellow-400 mb-2">
                  Enciclopédia da vida dos personagens bíblicos (De A a Z)
                </h3>
                <p className="text-lg md:text-xl text-white/90 mb-3">
                  Descubra quem foram os homens e mulheres que marcaram a história da fé! Nesta enciclopédia organizada de A a Z, você encontrará perfis completos de personagens bíblicos — suas origens, missões, erros, vitórias e lições de vida.
                </p>
                <p className="text-lg">
                  <span className="text-red-500 line-through">De: R$49,90</span>{" "}
                  <span className="text-white">por</span>{" "}
                  <span className="text-yellow-400 font-bold text-2xl">GRATUITO</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
