export const ValueProposition = () => {
  const features = [
    "suas experiências amorosas,",
    "seus padrões emocionais,",
    "seus medos e bloqueios,",
    "e o que o Espírito Santo está te direcionando nesta fase.",
  ];

  return (
    <section className="py-8 px-4 md:px-8 bg-cream">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-6 animate-fade-in-up">
          <p className="text-lg md:text-xl text-foreground/90 mb-6 leading-relaxed text-center">
            Existem promessas sobre a sua vida que ainda não se cumpriram, e essa oração é pra destravar isso.
          </p>
        </div>

        <div className="bg-primary/5 border-2 border-accent rounded-2xl p-8 md:p-12 shadow-elegant animate-scale-in mb-6">
          <h3 className="text-xl md:text-3xl font-serif font-bold text-primary mb-4 text-center leading-tight">
            Aqui, você vai receber uma oração completamente personalizada
          </h3>

          <p className="text-base md:text-lg text-foreground/80 leading-relaxed text-center">
            Escrita para a sua história, para as suas feridas, para o tipo de homem que você deseja e para o propósito
            que Deus já preparou para você viver a dois.
          </p>
        </div>

        <div className="bg-red-50 border-2 border-red-300 rounded-xl p-6 mb-4 animate-fade-in-up">
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <span className="text-red-600 text-2xl flex-shrink-0">✗</span>
              <p className="text-base md:text-lg text-red-800">Não é uma oração genérica.</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-red-600 text-2xl flex-shrink-0">✗</span>
              <p className="text-base md:text-lg text-red-800">Não é uma frase motivacional.</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-red-600 text-2xl flex-shrink-0">✗</span>
              <p className="text-base md:text-lg text-red-800">Não é algo que você encontra no YouTube.</p>
            </div>
          </div>
        </div>

        <div className="bg-green-50 border-2 border-green-300 rounded-xl p-6 animate-scale-in">
          <div className="space-y-3">
            {features.map((feature, index) => (
              <div key={index} className="flex items-start gap-4">
                <span className="text-green-600 text-2xl flex-shrink-0">✓</span>
                <p className="text-base md:text-lg text-green-800 pt-1">{feature}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
