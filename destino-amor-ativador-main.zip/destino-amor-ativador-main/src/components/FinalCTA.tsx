import { Button } from "@/components/ui/button";

export const FinalCTA = () => {
  return (
    <section className="py-16 px-4 md:px-8 bg-gradient-to-br from-primary via-wine-dark to-primary">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-2xl md:text-4xl font-serif text-primary-foreground mb-6 leading-tight animate-fade-in">
          Porque existem chaves espirituais que, quando liberadas, mudam tudo.
        </h2>
        
        <p className="text-lg md:text-xl text-primary-foreground/90 mb-10 leading-relaxed animate-fade-in-up">
          Descubra a oração personalizada que te aproxima do seu futuro marido.
        </p>

        <div className="animate-scale-in">
          <Button 
            size="lg"
            className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-lg px-12 py-6 rounded-full shadow-elegant hover:shadow-soft transition-smooth hover:scale-105"
          >
            Receber Minha Oração Personalizada
          </Button>
        </div>

        <p className="text-sm text-primary-foreground/70 mt-8 animate-fade-in">
          Preparada para ativar o seu destino no amor?
        </p>
      </div>
    </section>
  );
};
