import testimonial1 from "@/assets/testimonial-1.jpg";
import testimonial2 from "@/assets/testimonial-2.png";
import testimonial3 from "@/assets/testimonial-3.png";
import testimonial4 from "@/assets/testimonial-4.png";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const testimonials = [
  { id: 1, image: testimonial1, alt: "Depoimento 1" },
  { id: 2, image: testimonial2, alt: "Depoimento 2" },
  { id: 3, image: testimonial3, alt: "Depoimento 3" },
  { id: 4, image: testimonial4, alt: "Depoimento 4" },
];

export const Testimonials = () => {
  return (
    <section className="py-6 bg-cream">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-serif text-wine text-center mb-8 font-bold">
          <span className="block text-wine/70 text-lg md:text-xl font-normal mb-2">Veja os resultados reais</span>
          O que elas dizem sobre a oração
        </h2>
        
        <div className="max-w-md mx-auto">
          <Carousel
            opts={{
              align: "center",
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent>
              {testimonials.map((testimonial) => (
                <CarouselItem key={testimonial.id}>
                  <div className="p-2">
                    <img
                      src={testimonial.image}
                      alt={testimonial.alt}
                      className="w-full h-auto rounded-lg shadow-lg"
                    />
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="left-0 md:-left-12 bg-wine text-cream hover:bg-wine/90 border-none" />
            <CarouselNext className="right-0 md:-right-12 bg-wine text-cream hover:bg-wine/90 border-none" />
          </Carousel>
        </div>
      </div>
    </section>
  );
};
