import whatsappPhone from "@/assets/whatsapp-phone-new.png";
import brainReprogramming from "@/assets/brain-reprogramming.png";
import womanPraying from "@/assets/woman-praying.png";

export const WhatYouReceive = () => {
  return (
    <section className="pb-10 px-4 md:px-8 bg-black">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-5xl font-bold text-yellow-400 text-center mb-8">
          O que você recebe:
        </h2>

        <div className="space-y-6">
          {/* Card 1 - WhatsApp */}
          <div className="bg-gradient-to-b from-gray-900 to-gray-800 rounded-3xl p-6 md:p-8 border border-gray-700">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="w-48 h-48 flex-shrink-0">
                <img 
                  src={whatsappPhone}
                  alt="WhatsApp no celular"
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold text-yellow-400 mb-2">
                  Acesso imediato e vitalício
                </h3>
                <p className="text-lg md:text-xl text-white/90">
                  Receba o resultado direto no seu Whatsapp e o faça quantas vezes quiser.
                </p>
              </div>
            </div>
          </div>

          {/* Card 2 - Limpezas Terapêuticas */}
          <div className="bg-gradient-to-b from-gray-900 to-gray-800 rounded-3xl p-6 md:p-8 border border-gray-700">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="w-48 h-48 flex-shrink-0">
                <img 
                  src={brainReprogramming}
                  alt="Cérebro com engrenagens - Reprogramação Mental"
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold text-yellow-400 mb-2">
                  Limpezas Terapêuticas e Reprogramação de Crenças
                </h3>
                <p className="text-lg md:text-xl text-white/90">
                  Tenha acesso a aulas exclusivas para seu desenvolvimento pessoal!
                </p>
              </div>
            </div>
          </div>

          {/* Card 3 - Oração de Quebra */}
          <div className="bg-gradient-to-b from-gray-900 to-gray-800 rounded-3xl p-6 md:p-8 border border-gray-700">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="w-48 h-48 flex-shrink-0">
                <img 
                  src={womanPraying}
                  alt="Mulher orando fervorosamente"
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold text-yellow-400 mb-2">
                  Oração de Quebra de Maldições e Traumas Genéticos
                </h3>
                <p className="text-lg md:text-xl text-white/90">
                  Receba uma oração poderosa para quebrar esse ciclo de maldições hereditárias e traumas que passam de geração em geração.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
