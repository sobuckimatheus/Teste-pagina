import guaranteeBadge from "@/assets/guarantee-badge-new.png";

export const Guarantee = () => {
  return (
    <section className="py-10 px-4 md:px-8 bg-black">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-6xl font-bold text-center mb-8">
          <span className="text-yellow-400">GARANTIA DE 7 DIAS</span>
        </h2>

        <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-3xl p-8 md:p-12 border border-gray-700">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="w-64 h-64 flex-shrink-0">
              <img src={guaranteeBadge} alt="Garantia de 7 dias" className="w-full h-full object-contain" />
            </div>
            <div className="flex-1 text-center md:text-left">
              <p className="text-xl md:text-2xl text-white leading-relaxed">
                Faça a Oração profética do seu futuro marido. Se não ficar satisfeito com o resultado e os conteúdos,
                devolvemos o valor para você na hora.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
