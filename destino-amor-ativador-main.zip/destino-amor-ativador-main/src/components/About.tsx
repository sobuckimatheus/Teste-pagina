import dianaPhoto from "@/assets/diana-therapist-new2.png";

export const About = () => {
  return (
    <section className="py-10 px-4 md:px-8 bg-black">
      <div className="max-w-6xl mx-auto">
        <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-3xl p-8 md:p-12 border border-gray-700">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="w-80 flex-shrink-0">
              <div className="relative">
                <img src={dianaPhoto} alt="Diana Mascarello" className="w-full h-auto object-cover rounded-3xl" />
              </div>
            </div>
            <div className="flex-1 text-center md:text-left">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Sobre a autora: Diana Mascarello</h2>

              <div className="flex flex-wrap justify-center md:justify-start gap-8 mb-6">
                <div className="text-center">
                  <p className="text-3xl md:text-4xl font-bold text-green-400">+140 mil</p>
                  <p className="text-white/80">seguidores</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl md:text-4xl font-bold text-green-400">+7 anos</p>
                  <p className="text-white/80">de experiência</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl md:text-4xl font-bold text-green-400">+1000</p>
                  <p className="text-white/80">Alunas Ativas</p>
                </div>
              </div>

              <p className="text-lg md:text-xl text-white/90 leading-relaxed">
                Sou terapeuta e descobri que minha missão é ajudar pessoas a atraírem bons relacionamentos através da
                reprogramação mental. No meu trabalho, você vai aprender formas de se libertar de traumas, medos,
                crenças limitantes e todos os bloqueios mentais e emocionais que te impedem de prosperar em todas as
                áreas da vida e atrair sua alma gêmea mais compatível.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
