import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqItems = [
  {
    question: "Vou receber a mesma oração que outra pessoa receber?",
    answer: "Não, cada oração é personalizada com base nos seus bloqueios e dificuldades, assim conseguimos criar uma oração de libertação e ao mesmo tempo, profética para estar alinhada com o amor que o Senhor sonhou para você."
  },
  {
    question: "Como vou acessar as aulas bônus?",
    answer: "Você vai receber um e-mail para acessar todos os produtos"
  },
  {
    question: "Como vocês vão saber todas as dificuldades que tenho para criar a oração?",
    answer: "Você vai responder um formulário com perguntas muito pessoas e específicas sobre a sua vida, assim vamos analisar e descobrir qual o melhor caminho. (Essa análise é feita de forma terapêutica)"
  },
  {
    question: "Posso criar mais de 1x a oração?",
    answer: "Sim, só responder o formulário novamente."
  }
];

export const FAQ = () => {
  return (
    <section className="py-16 px-4 bg-secondary/30">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-primary">
          Perguntas Frequentes
        </h2>
        
        <Accordion type="single" collapsible className="space-y-4">
          {faqItems.map((item, index) => (
            <AccordionItem 
              key={index} 
              value={`item-${index}`}
              className="bg-card rounded-lg px-6 border-border"
            >
              <AccordionTrigger className="text-left text-foreground hover:text-primary">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};
