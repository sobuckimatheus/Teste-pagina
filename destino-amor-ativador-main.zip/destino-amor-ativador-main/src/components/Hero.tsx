import heroDesktop from "@/assets/hero-desktop.png";
import heroMobile from "@/assets/hero-mobile-new.png";

export const Hero = () => {
  return (
    <section className="relative w-full">
      {/* Desktop Image */}
      <div className="hidden md:block w-full h-screen">
        <img
          src={heroDesktop}
          alt="Oração Profética do Seu Futuro Marido"
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Mobile Image */}
      <div className="md:hidden w-full">
        <img
          src={heroMobile}
          alt="Oração Profética do Seu Futuro Marido"
          className="w-full h-auto"
        />
      </div>
    </section>
  );
};
