import womanPraying from "@/assets/woman-praying-new.jpg";

export const PrayerAlignment = () => {
  return (
    <section className="py-12 px-4 md:px-8 bg-black">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-2xl md:text-3xl lg:text-4xl text-white/90 font-serif leading-relaxed mb-8">
          Uma oração que te <span className="text-yellow-400 font-semibold">alinha</span>, te <span className="text-yellow-400 font-semibold">limpa</span>, te <span className="text-yellow-400 font-semibold">fortalece</span>… e profetiza o caminho até o seu futuro marido.
        </h2>
        
        <img 
          src={womanPraying} 
          alt="Mulher orando com a Bíblia"
          className="w-full h-auto rounded-2xl shadow-2xl"
        />
      </div>
    </section>
  );
};
